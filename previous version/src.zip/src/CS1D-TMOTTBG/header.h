#ifndef HEADER_H
#define HEADER_H

#include <QtDebug>
#include <QString>


#endif // HEADER_H
