/********************************************************************************
** Form generated from reading UI file 'admineditselecteduserwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMINEDITSELECTEDUSERWINDOW_H
#define UI_ADMINEDITSELECTEDUSERWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AdminEditSelectedUserWindow
{
public:
    QWidget *centralwidget;
    QLabel *errorOutputLabel;
    QSplitter *splitter;
    QPushButton *createButton;
    QPushButton *cancelButton;
    QPushButton *resetButton;
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QLabel *label_3;
    QLineEdit *emailInputBox;
    QLineEdit *usernameInputBox;
    QLabel *label_4;
    QLabel *label_5;
    QLineEdit *passwordInputBox;
    QLabel *label_6;
    QLabel *label_8;
    QLineEdit *addressInputBox;
    QLabel *label_11;
    QComboBox *countrySelectionBox;
    QLabel *label_7;
    QLineEdit *cityInputBox;
    QLineEdit *zipCodeInputBox;
    QComboBox *cellProvidorSelectionBox;
    QLineEdit *cellPhoneInputBox;
    QLabel *label_12;
    QLabel *label;
    QLineEdit *firstNameInputBox;
    QLineEdit *lastNameInputBox;
    QLabel *label_2;
    QLabel *label_13;
    QPushButton *deleteButton;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *AdminEditSelectedUserWindow)
    {
        if (AdminEditSelectedUserWindow->objectName().isEmpty())
            AdminEditSelectedUserWindow->setObjectName(QStringLiteral("AdminEditSelectedUserWindow"));
        AdminEditSelectedUserWindow->resize(635, 242);
        centralwidget = new QWidget(AdminEditSelectedUserWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        errorOutputLabel = new QLabel(centralwidget);
        errorOutputLabel->setObjectName(QStringLiteral("errorOutputLabel"));
        errorOutputLabel->setGeometry(QRect(240, 190, 211, 16));
        errorOutputLabel->setStyleSheet(QStringLiteral("color: rgb(170, 0, 0);"));
        splitter = new QSplitter(centralwidget);
        splitter->setObjectName(QStringLiteral("splitter"));
        splitter->setGeometry(QRect(470, 190, 150, 23));
        splitter->setOrientation(Qt::Horizontal);
        createButton = new QPushButton(splitter);
        createButton->setObjectName(QStringLiteral("createButton"));
        splitter->addWidget(createButton);
        cancelButton = new QPushButton(splitter);
        cancelButton->setObjectName(QStringLiteral("cancelButton"));
        cancelButton->setAutoDefault(false);
        splitter->addWidget(cancelButton);
        resetButton = new QPushButton(centralwidget);
        resetButton->setObjectName(QStringLiteral("resetButton"));
        resetButton->setGeometry(QRect(10, 190, 75, 23));
        resetButton->setAutoDefault(false);
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 10, 611, 171));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QStringLiteral("label_3"));

        gridLayout->addWidget(label_3, 1, 0, 1, 1);

        emailInputBox = new QLineEdit(layoutWidget);
        emailInputBox->setObjectName(QStringLiteral("emailInputBox"));

        gridLayout->addWidget(emailInputBox, 1, 1, 1, 1);

        usernameInputBox = new QLineEdit(layoutWidget);
        usernameInputBox->setObjectName(QStringLiteral("usernameInputBox"));

        gridLayout->addWidget(usernameInputBox, 2, 1, 1, 1);

        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QStringLiteral("label_4"));

        gridLayout->addWidget(label_4, 2, 0, 1, 1);

        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QStringLiteral("label_5"));

        gridLayout->addWidget(label_5, 2, 2, 1, 1);

        passwordInputBox = new QLineEdit(layoutWidget);
        passwordInputBox->setObjectName(QStringLiteral("passwordInputBox"));

        gridLayout->addWidget(passwordInputBox, 2, 3, 1, 1);

        label_6 = new QLabel(layoutWidget);
        label_6->setObjectName(QStringLiteral("label_6"));

        gridLayout->addWidget(label_6, 3, 0, 1, 1);

        label_8 = new QLabel(layoutWidget);
        label_8->setObjectName(QStringLiteral("label_8"));

        gridLayout->addWidget(label_8, 3, 2, 1, 1);

        addressInputBox = new QLineEdit(layoutWidget);
        addressInputBox->setObjectName(QStringLiteral("addressInputBox"));

        gridLayout->addWidget(addressInputBox, 3, 1, 1, 1);

        label_11 = new QLabel(layoutWidget);
        label_11->setObjectName(QStringLiteral("label_11"));

        gridLayout->addWidget(label_11, 4, 2, 1, 1);

        countrySelectionBox = new QComboBox(layoutWidget);
        countrySelectionBox->setObjectName(QStringLiteral("countrySelectionBox"));

        gridLayout->addWidget(countrySelectionBox, 4, 3, 1, 1);

        label_7 = new QLabel(layoutWidget);
        label_7->setObjectName(QStringLiteral("label_7"));

        gridLayout->addWidget(label_7, 4, 0, 1, 1);

        cityInputBox = new QLineEdit(layoutWidget);
        cityInputBox->setObjectName(QStringLiteral("cityInputBox"));

        gridLayout->addWidget(cityInputBox, 4, 1, 1, 1);

        zipCodeInputBox = new QLineEdit(layoutWidget);
        zipCodeInputBox->setObjectName(QStringLiteral("zipCodeInputBox"));

        gridLayout->addWidget(zipCodeInputBox, 3, 3, 1, 1);

        cellProvidorSelectionBox = new QComboBox(layoutWidget);
        cellProvidorSelectionBox->setObjectName(QStringLiteral("cellProvidorSelectionBox"));

        gridLayout->addWidget(cellProvidorSelectionBox, 5, 3, 1, 1);

        cellPhoneInputBox = new QLineEdit(layoutWidget);
        cellPhoneInputBox->setObjectName(QStringLiteral("cellPhoneInputBox"));

        gridLayout->addWidget(cellPhoneInputBox, 5, 1, 1, 1);

        label_12 = new QLabel(layoutWidget);
        label_12->setObjectName(QStringLiteral("label_12"));

        gridLayout->addWidget(label_12, 5, 0, 1, 1);

        label = new QLabel(layoutWidget);
        label->setObjectName(QStringLiteral("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        firstNameInputBox = new QLineEdit(layoutWidget);
        firstNameInputBox->setObjectName(QStringLiteral("firstNameInputBox"));

        gridLayout->addWidget(firstNameInputBox, 0, 1, 1, 1);

        lastNameInputBox = new QLineEdit(layoutWidget);
        lastNameInputBox->setObjectName(QStringLiteral("lastNameInputBox"));

        gridLayout->addWidget(lastNameInputBox, 0, 3, 1, 1);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout->addWidget(label_2, 0, 2, 1, 1);

        label_13 = new QLabel(layoutWidget);
        label_13->setObjectName(QStringLiteral("label_13"));

        gridLayout->addWidget(label_13, 5, 2, 1, 1);

        deleteButton = new QPushButton(centralwidget);
        deleteButton->setObjectName(QStringLiteral("deleteButton"));
        deleteButton->setGeometry(QRect(100, 190, 75, 23));
        deleteButton->setAutoDefault(false);
        AdminEditSelectedUserWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(AdminEditSelectedUserWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        AdminEditSelectedUserWindow->setStatusBar(statusbar);

        retranslateUi(AdminEditSelectedUserWindow);

        QMetaObject::connectSlotsByName(AdminEditSelectedUserWindow);
    } // setupUi

    void retranslateUi(QMainWindow *AdminEditSelectedUserWindow)
    {
        AdminEditSelectedUserWindow->setWindowTitle(QApplication::translate("AdminEditSelectedUserWindow", "MainWindow", 0));
        errorOutputLabel->setText(QString());
        createButton->setText(QApplication::translate("AdminEditSelectedUserWindow", "Save", 0));
        cancelButton->setText(QApplication::translate("AdminEditSelectedUserWindow", "Cancel", 0));
        resetButton->setText(QApplication::translate("AdminEditSelectedUserWindow", "Reset", 0));
        label_3->setText(QApplication::translate("AdminEditSelectedUserWindow", "E-Mail", 0));
        emailInputBox->setText(QString());
        usernameInputBox->setText(QString());
        label_4->setText(QApplication::translate("AdminEditSelectedUserWindow", "Username", 0));
        label_5->setText(QApplication::translate("AdminEditSelectedUserWindow", "Password", 0));
        passwordInputBox->setText(QString());
        label_6->setText(QApplication::translate("AdminEditSelectedUserWindow", "Address", 0));
        label_8->setText(QApplication::translate("AdminEditSelectedUserWindow", "Zip Code", 0));
        addressInputBox->setText(QString());
        label_11->setText(QApplication::translate("AdminEditSelectedUserWindow", "Country", 0));
        label_7->setText(QApplication::translate("AdminEditSelectedUserWindow", "City", 0));
        label_12->setText(QApplication::translate("AdminEditSelectedUserWindow", "Cell Phone", 0));
        label->setText(QApplication::translate("AdminEditSelectedUserWindow", "First Name", 0));
        firstNameInputBox->setText(QString());
        lastNameInputBox->setText(QString());
        label_2->setText(QApplication::translate("AdminEditSelectedUserWindow", "Last Name", 0));
        label_13->setText(QApplication::translate("AdminEditSelectedUserWindow", " Cell Provider", 0));
        deleteButton->setText(QApplication::translate("AdminEditSelectedUserWindow", "Delete", 0));
    } // retranslateUi

};

namespace Ui {
    class AdminEditSelectedUserWindow: public Ui_AdminEditSelectedUserWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMINEDITSELECTEDUSERWINDOW_H
