/********************************************************************************
** Form generated from reading UI file 'displayvacationlistwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DISPLAYVACATIONLISTWINDOW_H
#define UI_DISPLAYVACATIONLISTWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_displayVacationListWindow
{
public:
    QWidget *centralwidget;
    QWidget *widget;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *displayVacationListWindow)
    {
        if (displayVacationListWindow->objectName().isEmpty())
            displayVacationListWindow->setObjectName(QStringLiteral("displayVacationListWindow"));
        displayVacationListWindow->resize(800, 600);
        centralwidget = new QWidget(displayVacationListWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        widget = new QWidget(centralwidget);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(9, 29, 781, 551));
        displayVacationListWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(displayVacationListWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        displayVacationListWindow->setStatusBar(statusbar);

        retranslateUi(displayVacationListWindow);

        QMetaObject::connectSlotsByName(displayVacationListWindow);
    } // setupUi

    void retranslateUi(QMainWindow *displayVacationListWindow)
    {
        displayVacationListWindow->setWindowTitle(QApplication::translate("displayVacationListWindow", "MainWindow", 0));
    } // retranslateUi

};

namespace Ui {
    class displayVacationListWindow: public Ui_displayVacationListWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DISPLAYVACATIONLISTWINDOW_H
