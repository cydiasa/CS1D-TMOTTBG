/********************************************************************************
** Form generated from reading UI file 'adminselectuserwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMINSELECTUSERWINDOW_H
#define UI_ADMINSELECTUSERWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AdminEditUserWindow
{
public:
    QWidget *centralwidget;
    QComboBox *comboBox;
    QPushButton *pushButton;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *AdminEditUserWindow)
    {
        if (AdminEditUserWindow->objectName().isEmpty())
            AdminEditUserWindow->setObjectName(QStringLiteral("AdminEditUserWindow"));
        AdminEditUserWindow->resize(666, 89);
        centralwidget = new QWidget(AdminEditUserWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        comboBox = new QComboBox(centralwidget);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(40, 20, 531, 22));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(580, 20, 75, 23));
        AdminEditUserWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(AdminEditUserWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        AdminEditUserWindow->setStatusBar(statusbar);

        retranslateUi(AdminEditUserWindow);

        QMetaObject::connectSlotsByName(AdminEditUserWindow);
    } // setupUi

    void retranslateUi(QMainWindow *AdminEditUserWindow)
    {
        AdminEditUserWindow->setWindowTitle(QApplication::translate("AdminEditUserWindow", "MainWindow", 0));
        pushButton->setText(QApplication::translate("AdminEditUserWindow", "Edit User", 0));
    } // retranslateUi

};

namespace Ui {
    class AdminEditUserWindow: public Ui_AdminEditUserWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMINSELECTUSERWINDOW_H
