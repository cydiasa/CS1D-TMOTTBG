/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QGroupBox *groupBox;
    QLabel *label_username;
    QLabel *label_password;
    QLineEdit *usernameInputBox;
    QLineEdit *passwordInputBox;
    QPushButton *pushButton_login;
    QLabel *label_status;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(344, 295);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        groupBox = new QGroupBox(centralWidget);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(20, 20, 311, 181));
        label_username = new QLabel(groupBox);
        label_username->setObjectName(QStringLiteral("label_username"));
        label_username->setGeometry(QRect(20, 40, 71, 16));
        label_password = new QLabel(groupBox);
        label_password->setObjectName(QStringLiteral("label_password"));
        label_password->setGeometry(QRect(20, 80, 61, 16));
        usernameInputBox = new QLineEdit(groupBox);
        usernameInputBox->setObjectName(QStringLiteral("usernameInputBox"));
        usernameInputBox->setGeometry(QRect(100, 40, 113, 22));
        passwordInputBox = new QLineEdit(groupBox);
        passwordInputBox->setObjectName(QStringLiteral("passwordInputBox"));
        passwordInputBox->setGeometry(QRect(100, 80, 113, 22));
        passwordInputBox->setEchoMode(QLineEdit::Password);
        pushButton_login = new QPushButton(groupBox);
        pushButton_login->setObjectName(QStringLiteral("pushButton_login"));
        pushButton_login->setGeometry(QRect(190, 140, 93, 28));
        label_status = new QLabel(centralWidget);
        label_status->setObjectName(QStringLiteral("label_status"));
        label_status->setGeometry(QRect(40, 210, 281, 16));
        MainWindow->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Login Window", 0));
        groupBox->setTitle(QApplication::translate("MainWindow", "Login", 0));
        label_username->setText(QApplication::translate("MainWindow", "Username", 0));
        label_password->setText(QApplication::translate("MainWindow", "Password", 0));
        usernameInputBox->setText(QApplication::translate("MainWindow", "admin", 0));
        passwordInputBox->setText(QApplication::translate("MainWindow", "admin", 0));
        pushButton_login->setText(QApplication::translate("MainWindow", "Login", 0));
        label_status->setText(QApplication::translate("MainWindow", "+ Status Selection", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
