/********************************************************************************
** Form generated from reading UI file 'admineditoutputlist.ui'
**
** Created by: Qt User Interface Compiler version 5.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMINEDITOUTPUTLIST_H
#define UI_ADMINEDITOUTPUTLIST_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AdminEditOutputList
{
public:
    QWidget *centralwidget;
    QPushButton *pushButton;
    QComboBox *comboBox;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *AdminEditOutputList)
    {
        if (AdminEditOutputList->objectName().isEmpty())
            AdminEditOutputList->setObjectName(QStringLiteral("AdminEditOutputList"));
        AdminEditOutputList->resize(785, 87);
        centralwidget = new QWidget(AdminEditOutputList);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(670, 20, 75, 23));
        comboBox = new QComboBox(centralwidget);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(50, 20, 591, 22));
        AdminEditOutputList->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(AdminEditOutputList);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        AdminEditOutputList->setStatusBar(statusbar);

        retranslateUi(AdminEditOutputList);

        QMetaObject::connectSlotsByName(AdminEditOutputList);
    } // setupUi

    void retranslateUi(QMainWindow *AdminEditOutputList)
    {
        AdminEditOutputList->setWindowTitle(QApplication::translate("AdminEditOutputList", "MainWindow", 0));
        pushButton->setText(QApplication::translate("AdminEditOutputList", "Edit", 0));
    } // retranslateUi

};

namespace Ui {
    class AdminEditOutputList: public Ui_AdminEditOutputList {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMINEDITOUTPUTLIST_H
