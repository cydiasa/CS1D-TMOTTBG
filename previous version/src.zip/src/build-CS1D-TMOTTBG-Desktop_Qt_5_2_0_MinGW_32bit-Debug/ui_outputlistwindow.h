/********************************************************************************
** Form generated from reading UI file 'outputlistwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_OUTPUTLISTWINDOW_H
#define UI_OUTPUTLISTWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>

QT_BEGIN_NAMESPACE

class Ui_OutputListWindow
{
public:
    QPushButton *pushButton;
    QLabel *label;
    QLineEdit *searchInputBox;
    QLabel *label_2;
    QLabel *label_3;
    QComboBox *searchTypeComboBox;
    QLabel *label_4;
    QComboBox *leagueComboBox;
    QComboBox *feildTypeComboBox;
    QTableWidget *tableWidget;

    void setupUi(QDialog *OutputListWindow)
    {
        if (OutputListWindow->objectName().isEmpty())
            OutputListWindow->setObjectName(QStringLiteral("OutputListWindow"));
        OutputListWindow->resize(1297, 642);
        pushButton = new QPushButton(OutputListWindow);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(1210, 10, 75, 23));
        label = new QLabel(OutputListWindow);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 10, 111, 13));
        searchInputBox = new QLineEdit(OutputListWindow);
        searchInputBox->setObjectName(QStringLiteral("searchInputBox"));
        searchInputBox->setGeometry(QRect(130, 8, 133, 20));
        label_2 = new QLabel(OutputListWindow);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(685, 10, 48, 13));
        label_3 = new QLabel(OutputListWindow);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(491, 10, 35, 13));
        searchTypeComboBox = new QComboBox(OutputListWindow);
        searchTypeComboBox->setObjectName(QStringLiteral("searchTypeComboBox"));
        searchTypeComboBox->setGeometry(QRect(339, 8, 141, 20));
        label_4 = new QLabel(OutputListWindow);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(273, 10, 59, 13));
        leagueComboBox = new QComboBox(OutputListWindow);
        leagueComboBox->setObjectName(QStringLiteral("leagueComboBox"));
        leagueComboBox->setGeometry(QRect(530, 8, 141, 20));
        feildTypeComboBox = new QComboBox(OutputListWindow);
        feildTypeComboBox->setObjectName(QStringLiteral("feildTypeComboBox"));
        feildTypeComboBox->setGeometry(QRect(739, 8, 69, 20));
        tableWidget = new QTableWidget(OutputListWindow);
        if (tableWidget->columnCount() < 8)
            tableWidget->setColumnCount(8);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(5, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(6, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(7, __qtablewidgetitem7);
        tableWidget->setObjectName(QStringLiteral("tableWidget"));
        tableWidget->setEnabled(true);
        tableWidget->setGeometry(QRect(10, 41, 1281, 591));
        tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);

        retranslateUi(OutputListWindow);

        QMetaObject::connectSlotsByName(OutputListWindow);
    } // setupUi

    void retranslateUi(QDialog *OutputListWindow)
    {
        OutputListWindow->setWindowTitle(QApplication::translate("OutputListWindow", "Dialog", 0));
        pushButton->setText(QApplication::translate("OutputListWindow", "Search", 0));
        label->setText(QApplication::translate("OutputListWindow", "Team Or Stadium Name", 0));
        label_2->setText(QApplication::translate("OutputListWindow", "Feild Type", 0));
        label_3->setText(QApplication::translate("OutputListWindow", "League", 0));
        searchTypeComboBox->clear();
        searchTypeComboBox->insertItems(0, QStringList()
         << QApplication::translate("OutputListWindow", "Stadiums & Team Names", 0)
         << QApplication::translate("OutputListWindow", "Stadiums Names Only", 0)
         << QApplication::translate("OutputListWindow", "Team Names Only", 0)
        );
        label_4->setText(QApplication::translate("OutputListWindow", "Serach Type", 0));
        leagueComboBox->clear();
        leagueComboBox->insertItems(0, QStringList()
         << QApplication::translate("OutputListWindow", "Major League Baseball", 0)
         << QApplication::translate("OutputListWindow", "American League", 0)
         << QApplication::translate("OutputListWindow", "National League", 0)
        );
        feildTypeComboBox->clear();
        feildTypeComboBox->insertItems(0, QStringList()
         << QApplication::translate("OutputListWindow", "Any", 0)
         << QApplication::translate("OutputListWindow", "Grass", 0)
         << QApplication::translate("OutputListWindow", "Astro Turf", 0)
        );
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("OutputListWindow", "Stadium Name", 0));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("OutputListWindow", "Team Name", 0));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("OutputListWindow", "Stadium Address", 0));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("OutputListWindow", "Phone Number", 0));
        QTableWidgetItem *___qtablewidgetitem4 = tableWidget->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QApplication::translate("OutputListWindow", "Date Opened", 0));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidget->horizontalHeaderItem(5);
        ___qtablewidgetitem5->setText(QApplication::translate("OutputListWindow", "Population", 0));
        QTableWidgetItem *___qtablewidgetitem6 = tableWidget->horizontalHeaderItem(6);
        ___qtablewidgetitem6->setText(QApplication::translate("OutputListWindow", "League", 0));
        QTableWidgetItem *___qtablewidgetitem7 = tableWidget->horizontalHeaderItem(7);
        ___qtablewidgetitem7->setText(QApplication::translate("OutputListWindow", "More Info", 0));
    } // retranslateUi

};

namespace Ui {
    class OutputListWindow: public Ui_OutputListWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_OUTPUTLISTWINDOW_H
