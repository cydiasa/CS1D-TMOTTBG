/********************************************************************************
** Form generated from reading UI file 'admineditselectedoutputlist.ui'
**
** Created by: Qt User Interface Compiler version 5.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMINEDITSELECTEDOUTPUTLIST_H
#define UI_ADMINEDITSELECTEDOUTPUTLIST_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AdminEditSelectedOutputList
{
public:
    QWidget *centralwidget;
    QPushButton *saveButton;
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QLineEdit *teamNameEditBox;
    QLineEdit *stadiumNameEditBox;
    QLabel *label_6;
    QLabel *label;
    QLineEdit *addressEditBox;
    QLabel *label_3;
    QLineEdit *phoneNumberEditBox;
    QLabel *label_2;
    QLabel *label_4;
    QComboBox *leagueTypeComboBox;
    QLabel *label_5;
    QLabel *label_7;
    QLabel *label_8;
    QComboBox *grassTypeComboBox;
    QLineEdit *openningDateEditBox;
    QLineEdit *seatingCapacityEditBox;
    QPushButton *cancelButton;
    QPushButton *cancelButton_2;
    QPushButton *cancelButton_3;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *AdminEditSelectedOutputList)
    {
        if (AdminEditSelectedOutputList->objectName().isEmpty())
            AdminEditSelectedOutputList->setObjectName(QStringLiteral("AdminEditSelectedOutputList"));
        AdminEditSelectedOutputList->resize(463, 346);
        centralwidget = new QWidget(AdminEditSelectedOutputList);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        saveButton = new QPushButton(centralwidget);
        saveButton->setObjectName(QStringLiteral("saveButton"));
        saveButton->setGeometry(QRect(280, 290, 75, 23));
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(20, 20, 421, 261));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        teamNameEditBox = new QLineEdit(layoutWidget);
        teamNameEditBox->setObjectName(QStringLiteral("teamNameEditBox"));

        gridLayout->addWidget(teamNameEditBox, 6, 1, 1, 1);

        stadiumNameEditBox = new QLineEdit(layoutWidget);
        stadiumNameEditBox->setObjectName(QStringLiteral("stadiumNameEditBox"));

        gridLayout->addWidget(stadiumNameEditBox, 0, 1, 1, 1);

        label_6 = new QLabel(layoutWidget);
        label_6->setObjectName(QStringLiteral("label_6"));

        gridLayout->addWidget(label_6, 5, 0, 1, 1);

        label = new QLabel(layoutWidget);
        label->setObjectName(QStringLiteral("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        addressEditBox = new QLineEdit(layoutWidget);
        addressEditBox->setObjectName(QStringLiteral("addressEditBox"));

        gridLayout->addWidget(addressEditBox, 1, 1, 1, 1);

        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QStringLiteral("label_3"));

        gridLayout->addWidget(label_3, 2, 0, 1, 1);

        phoneNumberEditBox = new QLineEdit(layoutWidget);
        phoneNumberEditBox->setObjectName(QStringLiteral("phoneNumberEditBox"));

        gridLayout->addWidget(phoneNumberEditBox, 2, 1, 1, 1);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QStringLiteral("label_4"));

        gridLayout->addWidget(label_4, 6, 0, 1, 1);

        leagueTypeComboBox = new QComboBox(layoutWidget);
        leagueTypeComboBox->setObjectName(QStringLiteral("leagueTypeComboBox"));

        gridLayout->addWidget(leagueTypeComboBox, 7, 1, 1, 1);

        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QStringLiteral("label_5"));

        gridLayout->addWidget(label_5, 4, 0, 1, 1);

        label_7 = new QLabel(layoutWidget);
        label_7->setObjectName(QStringLiteral("label_7"));

        gridLayout->addWidget(label_7, 7, 0, 1, 1);

        label_8 = new QLabel(layoutWidget);
        label_8->setObjectName(QStringLiteral("label_8"));

        gridLayout->addWidget(label_8, 3, 0, 1, 1);

        grassTypeComboBox = new QComboBox(layoutWidget);
        grassTypeComboBox->setObjectName(QStringLiteral("grassTypeComboBox"));

        gridLayout->addWidget(grassTypeComboBox, 5, 1, 1, 1);

        openningDateEditBox = new QLineEdit(layoutWidget);
        openningDateEditBox->setObjectName(QStringLiteral("openningDateEditBox"));

        gridLayout->addWidget(openningDateEditBox, 3, 1, 1, 1);

        seatingCapacityEditBox = new QLineEdit(layoutWidget);
        seatingCapacityEditBox->setObjectName(QStringLiteral("seatingCapacityEditBox"));

        gridLayout->addWidget(seatingCapacityEditBox, 4, 1, 1, 1);

        cancelButton = new QPushButton(centralwidget);
        cancelButton->setObjectName(QStringLiteral("cancelButton"));
        cancelButton->setGeometry(QRect(370, 290, 75, 23));
        cancelButton_2 = new QPushButton(centralwidget);
        cancelButton_2->setObjectName(QStringLiteral("cancelButton_2"));
        cancelButton_2->setGeometry(QRect(20, 290, 75, 23));
        cancelButton_3 = new QPushButton(centralwidget);
        cancelButton_3->setObjectName(QStringLiteral("cancelButton_3"));
        cancelButton_3->setGeometry(QRect(110, 290, 75, 23));
        AdminEditSelectedOutputList->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(AdminEditSelectedOutputList);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        AdminEditSelectedOutputList->setStatusBar(statusbar);

        retranslateUi(AdminEditSelectedOutputList);

        QMetaObject::connectSlotsByName(AdminEditSelectedOutputList);
    } // setupUi

    void retranslateUi(QMainWindow *AdminEditSelectedOutputList)
    {
        AdminEditSelectedOutputList->setWindowTitle(QApplication::translate("AdminEditSelectedOutputList", "MainWindow", 0));
        saveButton->setText(QApplication::translate("AdminEditSelectedOutputList", "Save", 0));
        label_6->setText(QApplication::translate("AdminEditSelectedOutputList", "Grass Type", 0));
        label->setText(QApplication::translate("AdminEditSelectedOutputList", "Stadium Name", 0));
        label_3->setText(QApplication::translate("AdminEditSelectedOutputList", "Phone Number", 0));
        label_2->setText(QApplication::translate("AdminEditSelectedOutputList", "Address", 0));
        label_4->setText(QApplication::translate("AdminEditSelectedOutputList", "Team Name", 0));
        leagueTypeComboBox->clear();
        leagueTypeComboBox->insertItems(0, QStringList()
         << QApplication::translate("AdminEditSelectedOutputList", "National League", 0)
         << QApplication::translate("AdminEditSelectedOutputList", "American League", 0)
        );
        label_5->setText(QApplication::translate("AdminEditSelectedOutputList", "Seating Capacity", 0));
        label_7->setText(QApplication::translate("AdminEditSelectedOutputList", "League Type", 0));
        label_8->setText(QApplication::translate("AdminEditSelectedOutputList", "Openning Date", 0));
        grassTypeComboBox->clear();
        grassTypeComboBox->insertItems(0, QStringList()
         << QApplication::translate("AdminEditSelectedOutputList", "Grass", 0)
         << QApplication::translate("AdminEditSelectedOutputList", "Astro Turf", 0)
        );
        cancelButton->setText(QApplication::translate("AdminEditSelectedOutputList", "Cancel", 0));
        cancelButton_2->setText(QApplication::translate("AdminEditSelectedOutputList", "Reset", 0));
        cancelButton_3->setText(QApplication::translate("AdminEditSelectedOutputList", "Delete", 0));
    } // retranslateUi

};

namespace Ui {
    class AdminEditSelectedOutputList: public Ui_AdminEditSelectedOutputList {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMINEDITSELECTEDOUTPUTLIST_H
