/********************************************************************************
** Form generated from reading UI file 'displayvacationcheckedpathwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DISPLAYVACATIONCHECKEDPATHWINDOW_H
#define UI_DISPLAYVACATIONCHECKEDPATHWINDOW_H

#include <QtCore/QVariant>
#include <QtWebKitWidgets/QWebView>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_displayVacationCheckedPathWindow
{
public:
    QWidget *centralwidget;
    QWebView *webDisplayBox;
    QLabel *outputLabel;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *displayVacationCheckedPathWindow)
    {
        if (displayVacationCheckedPathWindow->objectName().isEmpty())
            displayVacationCheckedPathWindow->setObjectName(QStringLiteral("displayVacationCheckedPathWindow"));
        displayVacationCheckedPathWindow->resize(1314, 675);
        centralwidget = new QWidget(displayVacationCheckedPathWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        webDisplayBox = new QWebView(centralwidget);
        webDisplayBox->setObjectName(QStringLiteral("webDisplayBox"));
        webDisplayBox->setGeometry(QRect(670, 10, 640, 640));
        webDisplayBox->setUrl(QUrl(QStringLiteral("about:blank")));
        outputLabel = new QLabel(centralwidget);
        outputLabel->setObjectName(QStringLiteral("outputLabel"));
        outputLabel->setGeometry(QRect(20, 20, 631, 621));
        displayVacationCheckedPathWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(displayVacationCheckedPathWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        displayVacationCheckedPathWindow->setStatusBar(statusbar);

        retranslateUi(displayVacationCheckedPathWindow);

        QMetaObject::connectSlotsByName(displayVacationCheckedPathWindow);
    } // setupUi

    void retranslateUi(QMainWindow *displayVacationCheckedPathWindow)
    {
        displayVacationCheckedPathWindow->setWindowTitle(QApplication::translate("displayVacationCheckedPathWindow", "MainWindow", 0));
        outputLabel->setText(QApplication::translate("displayVacationCheckedPathWindow", "TextLabel", 0));
    } // retranslateUi

};

namespace Ui {
    class displayVacationCheckedPathWindow: public Ui_displayVacationCheckedPathWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DISPLAYVACATIONCHECKEDPATHWINDOW_H
