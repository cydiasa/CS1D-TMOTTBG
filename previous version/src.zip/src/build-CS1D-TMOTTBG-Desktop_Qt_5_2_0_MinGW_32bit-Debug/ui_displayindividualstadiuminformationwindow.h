/********************************************************************************
** Form generated from reading UI file 'displayindividualstadiuminformationwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DISPLAYINDIVIDUALSTADIUMINFORMATIONWINDOW_H
#define UI_DISPLAYINDIVIDUALSTADIUMINFORMATIONWINDOW_H

#include <QtCore/QVariant>
#include <QtWebKitWidgets/QWebView>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DisplayIndividualStadiumInformationWindow
{
public:
    QWidget *centralwidget;
    QLabel *population;
    QLabel *grass;
    QLabel *openDate;
    QLabel *teamName;
    QLabel *phoneNumber;
    QLabel *address;
    QLabel *stadiumName;
    QWebView *webView;
    QPushButton *zoonIncreaseButton;
    QPushButton *zoonDecreaseButton;
    QLabel *label;
    QLabel *phoneNumber_2;
    QComboBox *distanceToDropDown;
    QLabel *distanceBetweenLabel;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *DisplayIndividualStadiumInformationWindow)
    {
        if (DisplayIndividualStadiumInformationWindow->objectName().isEmpty())
            DisplayIndividualStadiumInformationWindow->setObjectName(QStringLiteral("DisplayIndividualStadiumInformationWindow"));
        DisplayIndividualStadiumInformationWindow->resize(657, 814);
        centralwidget = new QWidget(DisplayIndividualStadiumInformationWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        population = new QLabel(centralwidget);
        population->setObjectName(QStringLiteral("population"));
        population->setGeometry(QRect(9, 72, 121, 16));
        grass = new QLabel(centralwidget);
        grass->setObjectName(QStringLiteral("grass"));
        grass->setGeometry(QRect(138, 72, 101, 16));
        grass->setAlignment(Qt::AlignCenter);
        openDate = new QLabel(centralwidget);
        openDate->setObjectName(QStringLiteral("openDate"));
        openDate->setGeometry(QRect(267, 72, 211, 16));
        openDate->setAlignment(Qt::AlignCenter);
        teamName = new QLabel(centralwidget);
        teamName->setObjectName(QStringLiteral("teamName"));
        teamName->setGeometry(QRect(504, 70, 131, 20));
        teamName->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        phoneNumber = new QLabel(centralwidget);
        phoneNumber->setObjectName(QStringLiteral("phoneNumber"));
        phoneNumber->setGeometry(QRect(10, 100, 261, 16));
        address = new QLabel(centralwidget);
        address->setObjectName(QStringLiteral("address"));
        address->setGeometry(QRect(397, 100, 241, 16));
        address->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        stadiumName = new QLabel(centralwidget);
        stadiumName->setObjectName(QStringLiteral("stadiumName"));
        stadiumName->setGeometry(QRect(9, 9, 641, 39));
        QFont font;
        font.setPointSize(24);
        stadiumName->setFont(font);
        stadiumName->setAlignment(Qt::AlignCenter);
        webView = new QWebView(centralwidget);
        webView->setObjectName(QStringLiteral("webView"));
        webView->setGeometry(QRect(10, 160, 640, 640));
        webView->setUrl(QUrl(QStringLiteral("about:blank")));
        zoonIncreaseButton = new QPushButton(centralwidget);
        zoonIncreaseButton->setObjectName(QStringLiteral("zoonIncreaseButton"));
        zoonIncreaseButton->setGeometry(QRect(570, 130, 31, 23));
        zoonDecreaseButton = new QPushButton(centralwidget);
        zoonDecreaseButton->setObjectName(QStringLiteral("zoonDecreaseButton"));
        zoonDecreaseButton->setGeometry(QRect(610, 130, 31, 23));
        label = new QLabel(centralwidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(540, 135, 26, 13));
        phoneNumber_2 = new QLabel(centralwidget);
        phoneNumber_2->setObjectName(QStringLiteral("phoneNumber_2"));
        phoneNumber_2->setGeometry(QRect(10, 130, 131, 16));
        distanceToDropDown = new QComboBox(centralwidget);
        distanceToDropDown->setObjectName(QStringLiteral("distanceToDropDown"));
        distanceToDropDown->setGeometry(QRect(150, 130, 201, 22));
        distanceBetweenLabel = new QLabel(centralwidget);
        distanceBetweenLabel->setObjectName(QStringLiteral("distanceBetweenLabel"));
        distanceBetweenLabel->setGeometry(QRect(360, 130, 61, 16));
        DisplayIndividualStadiumInformationWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(DisplayIndividualStadiumInformationWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        DisplayIndividualStadiumInformationWindow->setStatusBar(statusbar);

        retranslateUi(DisplayIndividualStadiumInformationWindow);

        QMetaObject::connectSlotsByName(DisplayIndividualStadiumInformationWindow);
    } // setupUi

    void retranslateUi(QMainWindow *DisplayIndividualStadiumInformationWindow)
    {
        DisplayIndividualStadiumInformationWindow->setWindowTitle(QApplication::translate("DisplayIndividualStadiumInformationWindow", "MainWindow", 0));
        population->setText(QApplication::translate("DisplayIndividualStadiumInformationWindow", "Population", 0));
        grass->setText(QApplication::translate("DisplayIndividualStadiumInformationWindow", "Grass", 0));
        openDate->setText(QApplication::translate("DisplayIndividualStadiumInformationWindow", "Openning Date", 0));
        teamName->setText(QApplication::translate("DisplayIndividualStadiumInformationWindow", "Team Name", 0));
        phoneNumber->setText(QApplication::translate("DisplayIndividualStadiumInformationWindow", "phoneNumber", 0));
        address->setText(QApplication::translate("DisplayIndividualStadiumInformationWindow", "Address", 0));
        stadiumName->setText(QApplication::translate("DisplayIndividualStadiumInformationWindow", "Stadium Name", 0));
        zoonIncreaseButton->setText(QApplication::translate("DisplayIndividualStadiumInformationWindow", "+", 0));
        zoonDecreaseButton->setText(QApplication::translate("DisplayIndividualStadiumInformationWindow", "-", 0));
        label->setText(QApplication::translate("DisplayIndividualStadiumInformationWindow", "Zoom", 0));
        phoneNumber_2->setText(QApplication::translate("DisplayIndividualStadiumInformationWindow", "Distance Between here and ", 0));
        distanceBetweenLabel->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class DisplayIndividualStadiumInformationWindow: public Ui_DisplayIndividualStadiumInformationWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DISPLAYINDIVIDUALSTADIUMINFORMATIONWINDOW_H
