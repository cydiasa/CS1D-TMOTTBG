/********************************************************************************
** Form generated from reading UI file 'dashboardadminwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DASHBOARDADMINWINDOW_H
#define UI_DASHBOARDADMINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DashBoardAdminWindow
{
public:
    QWidget *centralwidget;
    QPushButton *pushButton_2;
    QPushButton *pushButton;
    QLabel *label;
    QPushButton *pushButton_3;
    QPushButton *editListButton;
    QPushButton *editListButton_2;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *DashBoardAdminWindow)
    {
        if (DashBoardAdminWindow->objectName().isEmpty())
            DashBoardAdminWindow->setObjectName(QStringLiteral("DashBoardAdminWindow"));
        DashBoardAdminWindow->resize(800, 600);
        centralwidget = new QWidget(DashBoardAdminWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        pushButton_2 = new QPushButton(centralwidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(40, 20, 75, 23));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(690, 20, 75, 23));
        label = new QLabel(centralwidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(330, 30, 46, 13));
        pushButton_3 = new QPushButton(centralwidget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(690, 50, 75, 23));
        editListButton = new QPushButton(centralwidget);
        editListButton->setObjectName(QStringLiteral("editListButton"));
        editListButton->setGeometry(QRect(40, 60, 75, 23));
        editListButton_2 = new QPushButton(centralwidget);
        editListButton_2->setObjectName(QStringLiteral("editListButton_2"));
        editListButton_2->setGeometry(QRect(130, 20, 101, 23));
        DashBoardAdminWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(DashBoardAdminWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        DashBoardAdminWindow->setStatusBar(statusbar);

        retranslateUi(DashBoardAdminWindow);

        QMetaObject::connectSlotsByName(DashBoardAdminWindow);
    } // setupUi

    void retranslateUi(QMainWindow *DashBoardAdminWindow)
    {
        DashBoardAdminWindow->setWindowTitle(QApplication::translate("DashBoardAdminWindow", "MainWindow", 0));
        pushButton_2->setText(QApplication::translate("DashBoardAdminWindow", "List", 0));
        pushButton->setText(QApplication::translate("DashBoardAdminWindow", "Create User", 0));
        label->setText(QApplication::translate("DashBoardAdminWindow", "Admin", 0));
        pushButton_3->setText(QApplication::translate("DashBoardAdminWindow", "Edit Users", 0));
        editListButton->setText(QApplication::translate("DashBoardAdminWindow", "Edit List", 0));
        editListButton_2->setText(QApplication::translate("DashBoardAdminWindow", "Vacation Planner", 0));
    } // retranslateUi

};

namespace Ui {
    class DashBoardAdminWindow: public Ui_DashBoardAdminWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DASHBOARDADMINWINDOW_H
