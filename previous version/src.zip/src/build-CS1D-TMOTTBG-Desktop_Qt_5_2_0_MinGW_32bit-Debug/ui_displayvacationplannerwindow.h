/********************************************************************************
** Form generated from reading UI file 'displayvacationplannerwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DISPLAYVACATIONPLANNERWINDOW_H
#define UI_DISPLAYVACATIONPLANNERWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DisplayVacationPlannerWindow
{
public:
    QPushButton *pushButton;

    void setupUi(QWidget *DisplayVacationPlannerWindow)
    {
        if (DisplayVacationPlannerWindow->objectName().isEmpty())
            DisplayVacationPlannerWindow->setObjectName(QStringLiteral("DisplayVacationPlannerWindow"));
        DisplayVacationPlannerWindow->resize(399, 778);
        pushButton = new QPushButton(DisplayVacationPlannerWindow);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(290, 730, 75, 23));

        retranslateUi(DisplayVacationPlannerWindow);

        QMetaObject::connectSlotsByName(DisplayVacationPlannerWindow);
    } // setupUi

    void retranslateUi(QWidget *DisplayVacationPlannerWindow)
    {
        DisplayVacationPlannerWindow->setWindowTitle(QApplication::translate("DisplayVacationPlannerWindow", "Form", 0));
        pushButton->setText(QApplication::translate("DisplayVacationPlannerWindow", "Plan Trip", 0));
    } // retranslateUi

};

namespace Ui {
    class DisplayVacationPlannerWindow: public Ui_DisplayVacationPlannerWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DISPLAYVACATIONPLANNERWINDOW_H
